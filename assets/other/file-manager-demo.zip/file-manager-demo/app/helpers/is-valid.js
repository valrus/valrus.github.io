import { helper } from '@ember/component/helper';

export function isValid([file]) {
  if (typeof file !== 'object') {
    return false;
  } else if (typeof file.status !== 'string') {
    return false;
  } else {
    return (
      (file.status.toLowerCase() === 'available' || file.status.toLowerCase() === 'scheduled')
        && Boolean(file.name)
        && Boolean(file.device)
        && Boolean(file.path)
    );
  }
}

export default helper(isValid);
