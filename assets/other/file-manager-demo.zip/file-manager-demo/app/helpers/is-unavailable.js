import { helper } from '@ember/component/helper';

function isUnavailable([file]) {
  try {
    return file.status.toLowerCase() !== 'available';
  } catch (e) {
    if (e instanceof TypeError) {
      return false;
    } else {
      throw e;
    }
  }
}

export default helper(isUnavailable);
