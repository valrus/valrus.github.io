import Component from '@glimmer/component';
import { action, computed } from '@ember/object';
import { tracked } from "@glimmer/tracking";
import { A } from '@ember/array';
import EmberObject from '@ember/object';

import { isValid } from '../helpers/is-valid'

export default class FileManagerComponent extends Component {
  // this duplicates the entire data, which is not what I'd do
  // knowing what I know now about how args work
  @tracked files = A(this.args.data.map(function(fileData) {
    return EmberObject.create({selected: false, ...fileData});
  }));
  @tracked selectionSize = 0;
  @tracked summaryCheckboxChecked = false;

  // Computed properties for displaying selection summary

  @computed('selectionSize')
  get summaryCheckboxIndeterminate() {
    return (this.selectionSize < this.files.length && this.selectionSize > 0);
  }

  @computed('selectionSize')
  get selectionCountDescription() {
    if (this.selectionSize === 0) {
      return 'None selected';
    } else {
      return 'Selected ' + this.selectionSize;
    }
  }

  @computed('selectionSize')
  get noneSelected() {
    return (this.selectionSize === 0);
  }

  // Actions

  @action
  toggleAll() {
    // this is on change, so the state at this point is the opposite of the desired one
    var shouldSelect = !this.summaryCheckboxChecked;
    var newSelectionSize = 0;
    this.files.forEach(function(file) {
      if (file.status === 'available' && isValid([file])) {
        file.set('selected', shouldSelect);
        if (shouldSelect) {
          newSelectionSize += 1;
        }
      }
    });
    this.selectionSize = newSelectionSize;
  }

  @action
  toggleFile(fileToToggle) {
    this.files.forEach(fileObj => {
      if (fileObj.device === fileToToggle.device && fileObj.path === fileToToggle.path) {
        fileObj.set('selected', !fileObj.selected);
        this.selectionSize += (fileObj.selected === true ? 1 : -1);
      }
    });
    this.summaryCheckboxChecked = (this.selectionSize === this.files.length);
  }

  @action
  downloadFiles() {
    var result = Array.from(
      this.files.reduce((selectedFiles, file) => {
        if (file.selected) {
          selectedFiles.add(file.device + ' - ' + file.path);
        }
        return selectedFiles;
      }, new Set())
    );
    if (result.length > 0) {
      alert(result.join('\n'));
    }
  }
}
