import Route from '@ember/routing/route';

export default class FilesRoute extends Route {
  model() {
    return [
      {name: 'smss.exe', device: 'Stark', path: '\\Device\\HarddiskVolume2\\Windows\\System32\\smss.exe', status: 'available'},
      {name: 'netsh.exe', device: 'Targaryen', path: '\\Device\\HarddiskVolume2\\Windows\\System32\\netsh.exe', status: 'scheduled'},
      {name: 'uxtheme.dll', device: 'Lannister', path: '\\Device\\HarddiskVolume1\\Windows\\System32\\uxtheme.dll', status: 'available'},
      {name: 'cryptbase.dll', path: '\\Device\\HarddiskVolume1\\Windows\\System32\\cryptbase.dll', status: 'available'},
      {name: '7za.exe', device: 'Baratheon', path: '\\Device\\HarddiskVolume1\\temp\\7za.exe', status: 'available'}
    ];
  }
}
