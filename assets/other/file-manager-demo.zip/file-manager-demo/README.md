# file-manager-demo

This is a demonstration of an Ember component
that lists files, each of which includes a name, device, path and status.
Files with an "available" status can be selected and downloaded
(though the download functionality here is dummied out and just pops up an alert box).

## To run this

* Have Ember v3.15 installed
* `npm install` in this directory
* `ember serve` from this directory
* Visit the app at [http://localhost:4200](http://localhost:4200).
  The actual component lives at [http://localhost:4200/files](http://localhost:4200/files).
